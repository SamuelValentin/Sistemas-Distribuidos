class Cartas(){
    init__(nome, tipo, time, pais){
        self.nome = nome
        self.tipo = tipo
        self.time = time
        self.pais = pais
    }
}

Lista_cartas = { "Neymar" : Cartas obj("Neymar Jr","Lendario","PSG","Brasil"),
                "Cristiano" : Cartas obj("Cristiano Ronaldo","Lendario","Manchester United","Portugal"),
                "Messi" : Cartas obj("Lionel Messi","Lendario","PSG","Argentina"),
                "Paqueta" : Cartas obj("Paqueta","Raro","West Ham","Brasil"),
                "Benzema" : Cartas obj("Bezema","Lendario","Real Madrid","França"),
                "Gakpo" : Cartas obj("Gakpo","Raro","PSV","Holanda"),
                "Pepe" : Cartas obj("Pepe","Raro","Porto","Portugal"),
                "Theo" : Cartas obj("Theo Hernandez","Raro","Milan","França"),
                "Pedro" : Cartas obj("Pedro Guilherme","Raro","Flamengo","Brasil"),
                "Lukaku" : Cartas obj("Lukaku","Raro","Inter de Milão","Belgica"),
                "Bounou" : Cartas obj("Yassine Bounou","Comum","Sevilla","Marrocos")
}
